﻿using System.Windows.Controls;

namespace WiredBrainCoffee.Controls.Common
{
  public partial class NavigationControl : UserControl
  {
    public NavigationControl()
    {
      InitializeComponent();
    }
  }
}
