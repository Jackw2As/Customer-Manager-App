﻿using System.Windows.Controls;

namespace WiredBrainCoffee.Controls.Details
{
  public partial class CustomerDetailControl : UserControl
  {
    public CustomerDetailControl()
    {
      InitializeComponent();
    }
  }
}
