﻿using System.Windows;

namespace WiredBrainCoffee.CustomersApp.Wpf
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
  }
}
